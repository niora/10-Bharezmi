const questions = [
  "1. Geri dönüşüm kutularını evinizde kullanıyor musunuz?",
  "2. Plastik atıkları ayırıyor musunuz?",
  "3. Cam atıkları ayrı bir yere atıyor musunuz?",
  "4. Kağıtları çöpe değil geri dönüşüme atar mısınız?",
  "5. Elektronik atıkları ayrı toplar mısınız?",
  "6. Pil atıklarını kutuya atıyor musunuz?",
  "7. Metal içecek kutularını geri dönüştürüyor musunuz?",
  "8. Geri dönüştürülebilir ürünleri tercih eder misiniz?",
  "9. Poşet yerine bez çanta kullanır mısınız?",
  "10. Organik atıkları kompost yapıyor musunuz?",
  "11. Geri dönüşüm konusunda bilinçli misiniz?",
  "12. Geri dönüşüm hakkında eğitim aldınız mı?",
  "13. Atık yağları lavaboya döker misiniz?",
  "14. Sınıfınızda geri dönüşüm kutusu var mı?",
  "15. Ailenizle geri dönüşüm hakkında konuşur musunuz?"
];

const form = document.getElementById("anketForm");

questions.forEach((q, index) => {
  const div = document.createElement("div");
  div.innerHTML = `
    <p>${q}</p>
    <label><input type="radio" name="q${index}" value="Evet" required> Evet</label>
    <label><input type="radio" name="q${index}" value="Hayır"> Hayır</label>
    <label><input type="radio" name="q${index}" value="Bilmiyorum"> Bilmiyorum</label>
    <hr>
  `;
  form.appendChild(div);
});

function submitForm() {
  const answers = {};
  questions.forEach((_, i) => {
    const val = document.querySelector(`input[name="q${i}"]:checked`);
    answers[`soru${i+1}`] = val ? val.value : "";
  });

  const db = firebase.database();
  db.ref("anketCevaplari").push(answers, () => {
    window.location.href = "tesekkur.html";
  });
}
